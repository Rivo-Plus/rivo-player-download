// Loaded by index.html before the app bundle.
// In the browser build the app expects a remote backend for Xtream / M3U / Stalker
// requests. Point it at this extension's own background worker instead, which
// answers those requests locally (see background.js) — credentials never leave
// the browser except to the customer's own provider.
window.__IPTVNATOR_CONFIG__ = Object.assign(window.__IPTVNATOR_CONFIG__ || {}, {
    BACKEND_URL: `${location.origin}/api`,
});

// The app registers an Angular service worker when one is available. In an
// extension that would compete with background.js for the extension's scope,
// so hide the API and let the app run without it.
try {
    delete Navigator.prototype.serviceWorker;
} catch {
    // Older engines: leave it; registration failures are non-fatal in the app.
}
