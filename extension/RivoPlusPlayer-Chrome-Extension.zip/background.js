(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // .cache/vendor/iptv-playlist-parser/src/index.js
  var require_src = __commonJS({
    ".cache/vendor/iptv-playlist-parser/src/index.js"(exports, module) {
      "use strict";
      var ATTR_SCAN_RE = /([A-Za-z0-9-]+)="([^"]*)"/g;
      var NAME_CLEAN_RE = /="(.*?)"/g;
      var OPT_REFERRER_RE = /:http-referrer=(.*)/i;
      var OPT_USER_AGENT_RE = /:http-user-agent=(.*)/i;
      var QUOTE_RE = /"/g;
      var EXTGRP_VALUE_RE = /:(.*)/;
      var PARAM_USER_AGENT_RE = /user-agent=(\w[^&]*)/i;
      var PARAM_REFERER_RE = /referer=(\w[^&]*)/i;
      var EXTM3U_RE = /^#EXTM3U/i;
      var WANTED = [
        "tvg-id",
        "tvg-name",
        "tvg-logo",
        "tvg-url",
        "tvg-rec",
        "tvg-shift",
        "group-title",
        "referrer",
        "user-agent",
        "catchup",
        "catchup-days",
        "catchup-source",
        "timeshift",
        "lang",
        "radio"
      ];
      var W_LEN = WANTED.length;
      function scanAttributes(line) {
        ATTR_SCAN_RE.lastIndex = 0;
        let out = null;
        let m;
        while ((m = ATTR_SCAN_RE.exec(line)) !== null) {
          if (out === null) out = [];
          out.push(m[1], m[2]);
        }
        return out;
      }
      function distribute(attrs, fields) {
        if (attrs === null) return;
        let taken = 0;
        for (let a = 0; a < attrs.length; a += 2) {
          const lower = attrs[a].toLowerCase();
          for (let wIdx = 0; wIdx < W_LEN; wIdx++) {
            const bit = 1 << wIdx;
            if ((taken & bit) === 0 && lower.endsWith(WANTED[wIdx])) {
              taken |= bit;
              fields[wIdx] = attrs[a + 1];
            }
          }
          if (taken === (1 << W_LEN) - 1) return;
        }
      }
      function getName(trimmed) {
        const cleaned = trimmed.replace(NAME_CLEAN_RE, "");
        const comma = cleaned.indexOf(",");
        return comma === -1 ? "" : cleaned.slice(comma + 1);
      }
      function getOption(trimmed, regex) {
        const m = regex.exec(trimmed);
        return m !== null && m[1] ? m[1].replace(QUOTE_RE, "") : "";
      }
      function getParameter(trimmed, regex) {
        const pipe = trimmed.lastIndexOf("|");
        const params = pipe === -1 ? trimmed : trimmed.slice(pipe + 1);
        const m = regex.exec(params);
        return m !== null && m[1] ? m[1] : "";
      }
      function parseHeader(firstLine) {
        const attrs = {};
        const scanned = scanAttributes(firstLine);
        if (scanned !== null) {
          for (const name of ["x-tvg-url", "url-tvg"]) {
            for (let a = 0; a < scanned.length; a += 2) {
              if (scanned[a].toLowerCase().endsWith(name)) {
                if (scanned[a + 1]) attrs[name] = scanned[a + 1];
                break;
              }
            }
          }
        }
        return { attrs, raw: firstLine };
      }
      var Parser = {};
      Parser.parse = (content) => {
        if (typeof content !== "string") {
          if (typeof Buffer !== "undefined" && Buffer.isBuffer(content)) {
            content = content.toString("utf8");
          } else {
            throw new TypeError(
              "parse() expects an M3U playlist as a string or Buffer, got " + (content === null ? "null" : typeof content)
            );
          }
        }
        if (content.charCodeAt(0) === 65279) content = content.slice(1);
        const lines = content.split(/\r?\n/);
        let headerIndex = 0;
        while (headerIndex < lines.length && lines[headerIndex].trim().length === 0) {
          headerIndex++;
        }
        const headerLine = headerIndex < lines.length ? lines[headerIndex] : "";
        if (!EXTM3U_RE.test(headerLine.trim())) {
          throw new Error("Playlist is not valid");
        }
        const playlist = {
          header: parseHeader(headerLine.trim()),
          items: []
        };
        const items = playlist.items;
        const fields = new Array(W_LEN);
        let current = null;
        let currentRaw = null;
        let pendingKodiprops = null;
        for (let idx = headerIndex + 1; idx < lines.length; idx++) {
          const raw = lines[idx];
          const line = raw.trim();
          if (line.length !== 0 && line.charCodeAt(0) === 35) {
            if (line.startsWith("#EXTINF:")) {
              fields.fill("");
              distribute(scanAttributes(line), fields);
              current = {
                name: getName(line),
                tvg: {
                  id: fields[0],
                  name: fields[1],
                  logo: fields[2],
                  url: fields[3],
                  rec: fields[4],
                  shift: fields[5]
                },
                group: { title: fields[6] },
                http: { referrer: fields[7], "user-agent": fields[8] },
                url: void 0,
                raw,
                line: idx + 1,
                catchup: {
                  type: fields[9],
                  days: fields[10],
                  source: fields[11]
                },
                timeshift: fields[12],
                lang: fields[13],
                radio: fields[14]
              };
              if (pendingKodiprops !== null) {
                pendingKodiprops.push(raw);
                currentRaw = pendingKodiprops;
                current.raw = currentRaw.join("\r\n");
                pendingKodiprops = null;
              } else {
                currentRaw = null;
              }
              continue;
            }
            if (current === null) {
              if (line.length > 10 && line.slice(0, 10).toUpperCase() === "#KODIPROP:") {
                if (pendingKodiprops === null) pendingKodiprops = [];
                pendingKodiprops.push(raw);
              }
              continue;
            }
            if (line.startsWith("#EXTVLCOPT:")) {
              current.http.referrer = getOption(line, OPT_REFERRER_RE) || current.http.referrer;
              current.http["user-agent"] = getOption(line, OPT_USER_AGENT_RE) || current.http["user-agent"];
            } else if (line.startsWith("#EXTGRP:")) {
              const m = EXTGRP_VALUE_RE.exec(line);
              const value = m !== null && m[1] ? m[1].replace(QUOTE_RE, "") : "";
              current.group.title = value || current.group.title;
            }
            if (currentRaw === null) currentRaw = [current.raw];
            currentRaw.push(raw);
          } else {
            if (current === null) continue;
            const pipeIdx = line.indexOf("|");
            const url = pipeIdx === -1 ? line : line.slice(0, pipeIdx);
            if (url.length !== 0) {
              current.url = url;
              current.http["user-agent"] = getParameter(line, PARAM_USER_AGENT_RE) || current.http["user-agent"];
              current.http.referrer = getParameter(line, PARAM_REFERER_RE) || current.http.referrer;
              if (currentRaw === null) current.raw = current.raw + "\r\n" + raw;
              else {
                currentRaw.push(raw);
                current.raw = currentRaw.join("\r\n");
                currentRaw = null;
              }
              items.push(current);
              current = null;
            } else {
              if (currentRaw === null) currentRaw = [current.raw];
              currentRaw.push(raw);
            }
          }
        }
        if (current !== null) {
          if (currentRaw !== null) current.raw = currentRaw.join("\r\n");
          items.push(current);
        }
        return playlist;
      };
      module.exports = Parser;
    }
  });

  // src/background.js
  var import_iptv_playlist_parser = __toESM(require_src(), 1);
  var API_PREFIX = "/api";
  var APP_PAGE = "/index.html";
  var PROVIDER_USER_AGENT = "VLC/3.0.18 LibVLC/3.0.18";
  var XTREAM_API_ENDPOINT = /\/(?:get|player_api|panel_api)\.php$/i;
  var HEADER_RULE_ID = 1;
  self.addEventListener("install", () => self.skipWaiting());
  self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
  var headerRuleReady = chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [HEADER_RULE_ID],
    addRules: [
      {
        id: HEADER_RULE_ID,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "user-agent", operation: "set", value: PROVIDER_USER_AGENT },
            { header: "origin", operation: "remove" }
          ]
        },
        condition: {
          initiatorDomains: [chrome.runtime.id],
          resourceTypes: ["xmlhttprequest", "media", "other"]
        }
      }
    ]
  });
  chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: APP_PAGE });
  });
  self.addEventListener("fetch", (event) => {
    const url = new URL(event.request.url);
    if (url.origin !== self.location.origin) return;
    if (url.pathname.startsWith(`${API_PREFIX}/`)) {
      event.respondWith(handleApi(event.request, url.pathname.slice(API_PREFIX.length), url.searchParams));
      return;
    }
    if (event.request.mode === "navigate" && !/\.[a-z0-9]+$/i.test(url.pathname)) {
      event.respondWith(fetch(APP_PAGE));
    }
  });
  async function handleApi(request, path, params) {
    try {
      await headerRuleReady;
      if (path === "/v1/instance") {
        return new Response("Not found", { status: 404 });
      }
      if (path === "/provider-targets" && request.method === "POST") {
        const { url } = await request.json();
        if (!url) return text("Missing url", 400);
        return json({ targetId: encodeTarget(url) });
      }
      if (path === "/xtream") return json(await xtreamRequest(params));
      if (path === "/parse") return await parsePlaylist(params);
      if (path === "/stalker") {
        return json({ status: 501, message: "Stalker portals are not supported in the browser extension" });
      }
      if (path === "/connectivity-guard/reset") return json({ reset: false });
      return text("Not found", 404);
    } catch (error) {
      return json({ status: 500, message: String(error?.message ?? error) }, 500);
    }
  }
  async function xtreamRequest(params) {
    const apiUrl = new URL(`${normalizeXtreamServerUrl(decodeTarget(params.get("targetId")))}/player_api.php`);
    for (const [key, value] of params) {
      if (["targetId", "userAgent", "connectionTest"].includes(key)) continue;
      apiUrl.searchParams.append(key, key === "username" || key === "password" ? value.trim() : value);
    }
    const action = apiUrl.searchParams.get("action") ?? "account";
    const startedAt = Date.now();
    let response;
    try {
      response = await fetch(apiUrl, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(24e4) });
    } catch (error) {
      console.warn(`[xtream] ${action} failed: ${error?.message ?? error} (${apiUrl.origin})`);
      return { status: 404, message: "Error: not found" };
    }
    if (!response.ok) {
      console.warn(`[xtream] ${action} \u2192 HTTP ${response.status} (${apiUrl.origin})`);
      return { status: response.status, message: response.statusText || `HTTP ${response.status}` };
    }
    const body = await response.text();
    const payload = parseBody(body);
    const size = Array.isArray(payload) ? `${payload.length} items` : typeof payload;
    console.info(`[xtream] ${action} \u2192 ${size}, ${(body.length / 1e6).toFixed(1)} MB in ${Date.now() - startedAt} ms`);
    return { payload, action: apiUrl.searchParams.get("action") ?? void 0 };
  }
  function normalizeXtreamServerUrl(value) {
    const url = new URL(value.trim());
    const basePath = url.pathname.replace(/\/+$/, "").replace(XTREAM_API_ENDPOINT, "");
    return `${url.origin}${basePath}`;
  }
  function providerFetch(url, signal) {
    return fetch(url, { signal });
  }
  async function parsePlaylist(params) {
    const url = decodeTarget(params.get("targetId"));
    const login = xtreamLoginFromM3uUrl(url);
    let refusal;
    try {
      const response = await providerFetch(url);
      if (response.ok) {
        const playlist = import_iptv_playlist_parser.default.parse(await response.text());
        if (playlist.items.length > 0 || !login) return playlistResponse(url, playlist);
        refusal = "an empty playlist";
      } else {
        refusal = `HTTP ${response.status}`;
        if (!login) return text(response.statusText || refusal, response.status);
      }
    } catch {
      if (!login) return text("Error, something went wrong", 500);
      refusal = "no answer";
    }
    console.warn(`[parse] M3U download refused (${refusal}), loading it via Xtream (${new URL(url).origin})`);
    try {
      return playlistResponse(url, import_iptv_playlist_parser.default.parse(await m3uFromXtream(login)));
    } catch (error) {
      console.warn(`[parse] Xtream fallback failed: ${error?.message ?? error}`);
      if (error instanceof XtreamAuthError) {
        return json({ code: "Wrong username or password, or the line is not active" }, 401);
      }
      return json({ code: `The provider refused the M3U download (${refusal}) and its Xtream login failed` }, 403);
    }
  }
  function playlistResponse(url, playlist) {
    const title = url.length > 1 ? url.slice(url.lastIndexOf("/") + 1) : "Playlist without title";
    const now = (/* @__PURE__ */ new Date()).toISOString();
    return json({
      id: guid(),
      _id: guid(),
      filename: title,
      title,
      count: playlist.items.length,
      playlist: { ...playlist, items: playlist.items.map((item) => ({ id: guid(), ...item })) },
      importDate: now,
      lastUsage: now,
      favorites: [],
      autoRefresh: false,
      url
    });
  }
  var XtreamAuthError = class extends Error {
  };
  function xtreamLoginFromM3uUrl(value) {
    const url = new URL(value);
    const username = url.searchParams.get("username")?.trim();
    const password = url.searchParams.get("password")?.trim();
    if (!/\/get\.php$/i.test(url.pathname) || !username || !password) return null;
    const output = url.searchParams.get("output")?.toLowerCase();
    return {
      server: normalizeXtreamServerUrl(value),
      username,
      password,
      liveExtension: output === "m3u8" || output === "hls" ? "m3u8" : "ts"
    };
  }
  async function m3uFromXtream({ server, username, password, liveExtension }) {
    const call = async (action) => {
      const apiUrl = new URL(`${server}/player_api.php`);
      apiUrl.searchParams.set("username", username);
      apiUrl.searchParams.set("password", password);
      if (action) apiUrl.searchParams.set("action", action);
      const response = await providerFetch(apiUrl.href, AbortSignal.timeout(24e4));
      if (!response.ok) throw new Error(`${action ?? "login"} \u2192 HTTP ${response.status}`);
      return parseBody(await response.text());
    };
    const account = await call();
    if (account?.user_info?.auth !== 1 && account?.user_info?.auth !== "1") throw new XtreamAuthError();
    const [liveCategories, liveStreams, vodCategories, vodStreams] = await Promise.all(
      ["get_live_categories", "get_live_streams", "get_vod_categories", "get_vod_streams"].map(
        (action) => call(action).then((value) => Array.isArray(value) ? value : [])
      )
    );
    const groups = new Map([...liveCategories, ...vodCategories].map((c) => [String(c.category_id), c.category_name]));
    const credentials = `${encodeURIComponent(username)}/${encodeURIComponent(password)}`;
    const attr = (value) => String(value ?? "").replace(/["\r\n]/g, " ");
    const entry = (stream, tvgId, streamUrl) => `#EXTINF:-1 tvg-id="${attr(tvgId)}" tvg-name="${attr(stream.name)}" tvg-logo="${attr(stream.stream_icon)}" group-title="${attr(groups.get(String(stream.category_id)))}",${String(stream.name ?? "").replace(/[\r\n]/g, " ")}
${streamUrl}`;
    const epg = `${server}/xmltv.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
    return [
      `#EXTM3U url-tvg="${epg}"`,
      ...liveStreams.map((s) => entry(s, s.epg_channel_id, `${server}/live/${credentials}/${s.stream_id}.${liveExtension}`)),
      ...vodStreams.map((s) => entry(s, "", `${server}/movie/${credentials}/${s.stream_id}.${s.container_extension || "mp4"}`))
    ].join("\n");
  }
  function encodeTarget(url) {
    const bytes = new TextEncoder().encode(url);
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function decodeTarget(targetId) {
    if (!targetId) throw new Error("Missing targetId");
    const binary = atob(targetId.replace(/-/g, "+").replace(/_/g, "/"));
    return new TextDecoder().decode(Uint8Array.from(binary, (c) => c.charCodeAt(0)));
  }
  function parseBody(body) {
    try {
      return JSON.parse(body);
    } catch {
      return body;
    }
  }
  function guid() {
    return Math.random().toString(36).slice(2);
  }
  function json(data, status = 200) {
    if (status < 200 || status > 599) status = 502;
    return new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json" } });
  }
  function text(body, status) {
    if (status < 200 || status > 599) status = 502;
    return new Response(body, { status, headers: { "content-type": "text/plain" } });
  }
})();
